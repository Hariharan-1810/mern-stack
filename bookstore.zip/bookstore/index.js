var express=require("express")
var bodyParser=require("body-parser")
var mongoose=require("mongoose")

const app=express()
app.set('view engine', 'ejs');

app.use(bodyParser.json())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))

mongoose.connect('mongodb://127.0.0.1:27017/bookstore')
var db=mongoose.connection
db.on('error',()=> console.log("Error in Connecting to Database"))
db.once('open',()=> console.log("Connected to Database"))

app.post("/sign_up",(req,res) => {
    var name= req.body.name
    var email=req.body.email
    var password=req.body.password

    var data={
        "name":name,
        "email":email,
        "password":password
    }
    db.collection('users').insertOne(data,(err,collection) => {
        if(err){
            throw err;
        }
        console.log("Record Inserted Succesfully")
    })
    return res.redirect('html.html')
})

var username;
app.post("/login",async (req,res) => {
    try{
        username= req.body.email
        var password= req.body.pass
        const result=await db.collection('users').findOne({email:username})
        const cursor = db.collection('featured').find(); 
        const fbook = await cursor.toArray(); 
        if(result.password==password){
            try {
                res.render('user.ejs',{
                    user:result,
                    featured:fbook
                });
            } catch (error) {
                console.error(error); 
            }
        }
        else{
            res.send("Wrong Password")
        }
    }
    catch{
        res.send("Wrong details")
    }
})
app.get('/books', async(req, res) => {
    try {
        const result=await db.collection('users').findOne({email:username})
        const cursor1 = db.collection('horror').find(); 
        const horror = await cursor1.toArray(); 
        const cursor2 = db.collection('adventure').find(); 
        const adventure = await cursor2.toArray(); 
        const cursor3 = db.collection('action').find(); 
        const action = await cursor3.toArray(); 
        const cursor4 = db.collection('romantic').find(); 
        const romantic = await cursor4.toArray(); 
        const cursor5 = db.collection('classic').find(); 
        const classic = await cursor5.toArray(); 
        const cursor6 = db.collection('fantasy').find(); 
        const fantasy = await cursor6.toArray(); 
        res.render('books.ejs', {
            user:result,
            horror:horror,
            adventure:adventure,
            action:action,
            romantic:romantic,
            classic:classic,
            fantasy:fantasy
        });
    } catch (error) {
        console.error(error); 
    }
});
app.get('/user', async(req, res) => {
    try {
        const result=await db.collection('users').findOne({email:username})
        const cursor = db.collection('featured').find(); 
        const fbook = await cursor.toArray(); 
        res.render('user.ejs',{
            user:result,
            featured:fbook
        });
    } catch (error) {
        console.error(error); 
    }
});
app.get('/cart', async(req, res) => {
    try {
        const result=await db.collection('users').findOne({email:username})
        const cursor = db.collection('cart').find(); 
        const cart = await cursor.toArray(); 
        res.render('cart.ejs',{
            user:result,
            cart:cart
        });
    } catch (error) {
        console.error(error); 
    }
});
app.post("/addcart",async (req,res) => {
    try{
        var title= req.body.title
        var img=req.body.img
        var price=req.body.price
        var genre=req.body.genre
        var data={
            "title":title,
            "img":img,
            "price":price,
            "genre":genre
        }
        db.collection('cart').insertOne(data,(err,collection) => {
            if(err){
                throw err;
            }
            console.log("Record Inserted Succesfully")
        })
        const result=await db.collection('users').findOne({email:username})
        const cursor1 = db.collection('horror').find(); 
        const horror = await cursor1.toArray(); 
        const cursor2 = db.collection('adventure').find(); 
        const adventure = await cursor2.toArray(); 
        const cursor3 = db.collection('action').find(); 
        const action = await cursor3.toArray(); 
        const cursor4 = db.collection('romantic').find(); 
        const romantic = await cursor4.toArray(); 
        const cursor5 = db.collection('classic').find(); 
        const classic = await cursor5.toArray(); 
        const cursor6 = db.collection('fantasy').find(); 
        const fantasy = await cursor6.toArray(); 
        res.render('books.ejs', {
            user:result,
            horror:horror,
            adventure:adventure,
            action:action,
            romantic:romantic,
            classic:classic,
            fantasy:fantasy
        });
    }
    catch{
        res.send("Wrong details")
    }
})
app.post('/removebook', async(req, res) => {
    try {
        var name=req.body.name;
        const result=await db.collection('users').findOne({email:username})
        db.collection('cart').deleteOne({title:name})
        const cursor = db.collection('cart').find(); 
        const cart = await cursor.toArray(); 
        res.render('cart.ejs', {
            user:result,
            cart: cart 
        });
    } catch (error) {
        console.error(error); 
    }
});

app.get("/",(req,res) => {
    res.set({
        "Allow-acces-Allow-Origin":'*'
    })
    return res.redirect('html.html')
}).listen(3000);

console.log("Listening on port 3000")